function showForm(formName) { // στην ουσια να δυο form ειναι κρυμμενα με none και μολις πατησεις Συνδεση Η Εγγραφη τοτε αυτο που πατησες γινεται active//
  document.getElementById('login').style.display = 'none'; 
  document.getElementById('register').style.display = 'none';
  document.getElementById(formName).style.display = 'block';
}

function checkLoginRegister() {
    const urlParams = new URLSearchParams(window.location.search); // Στην ουσια διαβαζει τα στοιχεια απο το URL (error , form)

    const error = urlParams.get('error'); // παιρνει το error και το αποθηκευει σε μια μεταβλητη και μετα με ενα if ελεγχει ολα τα πιθανα error//
    if (error) {
        if (error === 'invalid_login') alert("Τα στοιχεια συνδεσης είναι λανθασμενα.");
        if (error === 'not_logged_in') alert("Πρεπει να κανετε login για να συνεχισετε.");
        if (error === 'exists') alert(" Το username ή το email υπαρχει ηδη.");
        if (error === 'invalid_email') alert("Το email δεν ειναι εγκυρο.");
        if (error === 'invalid_name') alert("Το ονομα ή το επωνυμο πρεπει να περιεχουν μονο γραμματα.");
        if (error === 'weak_password') alert("Ο κωδικος πρεπει να ειναι 4-10 χαρακτηρες και να περιεχει τουλαχιστον εναν αριθμο.");
        if (error === 'empty_register') alert("Συμπληρωστε ολα τα πεδια στην εγγραφη.");
        if (error === 'empty_login') alert("Συμπληρωστε και τα δυο πεδια στη συνδεση.");
    }

    const success = urlParams.get('success'); // διαβαζει αν το υπαρχει success στο URL και ειναι registered //
    if (success === 'registered') {
        alert("✅ Η εγγραφή σας ολοκληρώθηκε επιτυχώς. Μπορείτε τώρα να συνδεθείτε!");
    }
}


window.onload = function() { // Βοηθαει ωστε να ειναι σιγουρο οτι ολη σελιδα εχει φορτωθει και ετσι αποφευγουμε να μην δειξουμε τα alert με τα erros //
    const urlParams = new URLSearchParams(window.location.search);
    const form = urlParams.get('form') || 'login';
    showForm(form);
    checkLoginRegister();
};
