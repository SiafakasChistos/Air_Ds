<?php
// Δηλωση στοιχειων διασυνδεσης //
$servername = "mysql:host=localhost;dbname=air_ds";
$username = "root";
$password = ""; 

try {
    // Δημιουργια PDO συνδεσης //
    $pdo = new PDO($servername, $username, $password);

    // Ρυθμιση λειτουργιας σφαλματων//
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // Αν αποτuχει η σuνδεση, εμφανισε το σφαλμα //
    echo "Σφαλμα συνδεσης: " . $e->getMessage();
}
?>
