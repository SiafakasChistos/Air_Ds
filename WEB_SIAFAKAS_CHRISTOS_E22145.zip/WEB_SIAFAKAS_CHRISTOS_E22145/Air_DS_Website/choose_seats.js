document.addEventListener("DOMContentLoaded", function () { // Περιμενει να φορτωθει ολη η HTML//
    const seatInfo = document.getElementById("seatInfo");
    const selectedSeatsInput = document.getElementById("selectedSeatsDisplay");
    const checkboxes = document.querySelectorAll('input[type="checkbox"][name="selected_seats[]"]');
 
    //Παιρνει οσες θεσεις εχουν επιλαγει τα checkboxes//
    // Βγαζει το value απο καθε checkbox, δηλαδη το ονομα της θεσης//
    //υπολογιζει το κοστος //
    function updateSeatInfo() {
        const selected = Array.from(checkboxes).filter(cb => cb.checked);
        const seatNames = selected.map(cb => cb.value);
        let totalCost = 0;

        seatNames.forEach(seat => {
            const row = parseInt(seat);
            if ([1, 11, 12].includes(row)) totalCost += 20;
            else if (row >= 2 && row <= 10) totalCost += 10;
        });

        // εμφανιση στον χρηστη
        selectedSeatsInput.value = seatNames.join(",");
        seatInfo.innerHTML = `
            <h3>Επιλεγμενες Θεσεις: ${seatNames.join(", ")}</h3>
            <p>Συνολικο Κοστος Θεσεων: €${totalCost}</p>
        `;
    }
  // Εδω τι γινεται οταν αλλαζει η κατασταση δηλαδη απο checked σε unchecked και αντιστροφα μετρα ποσες θεσεις ειναι επιλεγμενες //
  //Αν υπερβαινουν το επιτρεπομενο το maxseats απορριπτει την αλλαγη και εμφανιζει σχετικο μηνυμα//
  //Αν οχι καλει την updateSeatInfo και ανανεωνει τα δεδομενα//
    checkboxes.forEach(cb => {
        cb.addEventListener("change", () => {
            const selectedCount = Array.from(checkboxes).filter(cb => cb.checked).length;
            if (selectedCount > maxSeats) {
                cb.checked = false;
                alert(`Μπορειτε να επιλεξετε μόνο ${maxSeats} θεσεις.`);
            } else {
                updateSeatInfo();
            }
        });
    });
});

// ενας τελευταιος ελεγχος πριν γινει submit //
//An o αριθμος επιλεγμενων θεσεων δεν ισουται με το maxSeats τοτε εμφανιζει μηνυμα σφαλματος και εμποδιζει την υποβολη//
function validateSelection() {
    const selected = document.querySelectorAll('input[type="checkbox"][name="selected_seats[]"]:checked');
    if (selected.length !== maxSeats) {
        alert(`Πρεπει να επιλεξετε ακριβως ${maxSeats} θεσεις.`);
        return false;
    }
    return true;
}
