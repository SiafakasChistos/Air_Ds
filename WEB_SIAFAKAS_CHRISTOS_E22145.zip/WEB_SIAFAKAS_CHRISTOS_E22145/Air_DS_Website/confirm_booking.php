<?php
session_start();
include 'connection.php';

//Κλασικος ελεγχος//
if (!isset($_SESSION['user_id']) || !isset($_SESSION['reservation']) || !isset($_POST['selected_seats'])) {
    header("Location: Home.php");
    exit();
}

//Παιρνει απο το session τις πληροφοριες //
$reservation = $_SESSION['reservation'];
$selectedSeats = $_POST['selected_seats'];
$selectedSeatsArray = is_array($selectedSeats) ? $selectedSeats : explode(',', $selectedSeats);
$passengerCount = count($selectedSeatsArray);

// Ελεγχος επιβατων //
if (!isset($_SESSION['passenger_names'])) {
   die("Σφαλμα: Τα στοιχεια επιβατων δεν έχουν αποθηκευτει στη συνεδρια.");
}

$firstNames = $_SESSION['passenger_names']['first_names'];
$lastNames = $_SESSION['passenger_names']['last_names'];

// Κανει query για τα 2 αεροδρομια με τους αντιστοιχους code και παιρνει latitude , longitude και tax //
$stmt = $pdo->prepare("SELECT code, latitude, longitude, tax FROM airports WHERE code IN (?, ?)");
$stmt->execute([$reservation['departure'], $reservation['arrival']]);
$airports = $stmt->fetchAll(PDO::FETCH_ASSOC);

//Ξεχωριζει τα 2 αεροδρομια και αν καποιο λειπει εμφανιζει αντιστοιχο σφαλμα //
$departureAirport = $arrivalAirport = null;
foreach ($airports as $airport) {
    if ($airport['code'] === $reservation['departure']) {
        $departureAirport = $airport;
    } elseif ($airport['code'] === $reservation['arrival']) {
        $arrivalAirport = $airport;
    }
}

if (!$departureAirport || !$arrivalAirport) {
    die("Σφαλμα: Δεν βρεθηκαν αεροδρομια");
}

//Υπολογισμος αποστασης με την συναρτηση haversineDistance //
function haversineDistance($lat1, $lon1, $lat2, $lon2) {
    $R = 6371; // ακτίνα Γης σε km
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $lat1 = deg2rad($lat1);
    $lat2 = deg2rad($lat2);

    $a = sin($dLat/2) * sin($dLat/2) + cos($lat1) * cos($lat2) * sin($dLon/2) * sin($dLon/2);
    $c = 2 * asin(sqrt($a));
    return $R * $c;
}

//Υπολογισμος τους κοστους ανα επιβατη //
$distance = haversineDistance(
    $departureAirport['latitude'],
    $departureAirport['longitude'],
    $arrivalAirport['latitude'],
    $arrivalAirport['longitude']
);

$flightCost = $distance / 10;
$taxes = $departureAirport['tax'] + $arrivalAirport['tax'];

$seatCost = 0;
foreach ($selectedSeatsArray as $seat) {
    $row = (int)filter_var($seat, FILTER_SANITIZE_NUMBER_INT);
    if (in_array($row, [1, 11, 12])) $seatCost += 20;
    elseif ($row >= 2 && $row <= 10) $seatCost += 10;
    // αλλες σειρες εχουν 0 κοστος //
}

$ticketCost = $taxes + $flightCost + $seatCost;
$totalCost = $ticketCost * $passengerCount;
?>

<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <title>Επιβεβαιωση Κρατησης</title>
</head>
<?php include 'navbar.php'; ?>

<body>

<h2>Συνοψη Κρατησης</h2>

<h3>Επιβατες:</h3>
<ul>
  <?php
  for ($i = 0; $i < count($firstNames); $i++) {
      echo "<li>" . htmlspecialchars($firstNames[$i]) . " " . htmlspecialchars($lastNames[$i]) . "</li>";
  }
  ?>
</ul>

<h3>Πτηση:</h3>
<ul>
  <li>Αναχωρηση: <?= $reservation['departure'] ?></li>
  <li>Αφιξη: <?= $reservation['arrival'] ?></li>
  <li>Ημερομηνια: <?= $reservation['date'] ?></li>
</ul>

<h3>Θεσεις:</h3>
<ul>
  <?php foreach ($selectedSeatsArray as $seat): ?>
    <li><?= htmlspecialchars($seat) ?></li>
  <?php endforeach; ?>
</ul>

<h3>Κοστη:</h3>
<ul>
  <li>Αποσταση: <?= round($distance, 2) ?> km</li>
  <li>Φοροι: €<?= $taxes ?></li>
  <li>Κοστος Πτησης: €<?= round($flightCost, 2) ?></li>
  <li>Κοστος Θεσεων: €<?= $seatCost ?></li>
  <li><strong>Τελικο Κοστος: €<?= round($totalCost, 2) ?></strong></li>
</ul>

  <!-- Οταν πατηθει το κουμπι Κρατηση η φορμα στελνει τον χρηστη στο finalize_booking.php -->
<form action="finalize_booking.php" method="POST">
    <input type="hidden" name="confirmed_seats" value="<?= htmlspecialchars(implode(',', $selectedSeatsArray)) ?>">
    <input type="submit" value="Κρατηση">
</form>



</body>
<footer style="padding: 20px;">
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">

    <div>
      <h3>Τα στοιχεια Επικοινωνιας ειναι:</h3>
      <p>Όνομα: Air DS</p>
      <p>Τηλεφωνο: <a href="tel:+302109304070">2109304070</a></p>
      <p>Email: <a href="mailto:info@AIRINTERSALONIKA.gr">info@AIRINTERSALONIKA.gr</a></p>
    </div>

    <div>
      <h3>Η Τοποθεσια μας ειναι:</h3>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3146.522177474548!2d23.945142575701148!3d37.94159177194379!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1901ad9e75c61%3A0x38b215df0aeeb3aa!2zzpTOuc61zrjOvc6uz4IgzpHOtc-Bzr_Ou865zrzOrc69zrHPgiDOkc64zrfOvc-Ozr0gzpXOu861z4XOuM6tz4HOuc6_z4IgzpLOtc69zrnOts6tzrvOv8-C!5e0!3m2!1sel!2sgr!4v1747690775457!5m2!1sel!2sgr"
        width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
      </iframe>
    </div>

  </div>
</footer>
</html>