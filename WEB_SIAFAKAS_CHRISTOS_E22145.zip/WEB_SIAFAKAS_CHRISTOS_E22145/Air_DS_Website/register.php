<?php
session_start();
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') { // Εδω απλα παιρνει απο τη φορμα τα δεδομενα που εδωσε ο χρηστης//
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];

    if (empty($username) || empty($email) || empty($password) || empty($first_name) || empty($last_name)) {
        header("Location: login_register.php?error=empty_register&form=register"); // Δεν θα ενεργοποιηθει ποτε τον προλαβαινει ο browser//
        exit(); 
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { // Η FILTER_VALIDATE_EMAIL ειναι μια ετοιμη php function που ελεγχει αν το email ειναι σωστο(αναγραφω στο word που την βρηκα)//
        header("Location: login_register.php?error=invalid_email&form=register");
        exit();
    }
    if (!preg_match('/^[A-Za-z]+$/', $first_name) || !preg_match('/^[A-Za-z]+$/', $last_name)) { // πρεπει το ονομα και το εππωνυμο να εχουν μονο χαρακτηρες//
        header("Location: login_register.php?error=invalid_name&form=register");
        exit();
    }
    if (strlen($password) < 4 || strlen($password) > 10 || !preg_match('/\d/', $password)) {
        header("Location: login_register.php?error=weak_password&form=register"); // πρεπει το paasword συμφωνα με την εκφωνηση να εχει 4 μεχρι 10 χαρακτηρες και να εχει 1 τουλαχιστον αριθμο//
        exit();
    }

    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
    $stmt->execute([':username' => $username, ':email' => $email]);
    if ($stmt->fetch()) {
        header("Location: login_register.php?error=exists&form=register"); // Ελεγχει αν υπαρχει ηδη το username Η το email για να μην μπορει καποιος να κανει εγγραφη με το ιδιο email & username//
        exit();
    }

   
    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, first_name, last_name)
                           VALUES (:username, :password, :email, :first_name, :last_name)"); // Εισαγει τα στοιχεια στην βαση//
    $stmt->execute([
        ':username' => $username,
        ':password' => $password,
        ':email' => $email,
        ':first_name' => $first_name,
        ':last_name' => $last_name,
    ]);

    
    header("Location: login_register.php?success=registered&form=login"); //Αν  ολα ειναι σωστα σε γυρναει στην φορμα συνδεση για να κανεις συνδεση//
    exit();
}
