<?php
session_start();
include 'connection.php';

//Ο απαιρετητος ελεγχος για το αν ο χρηστης ειναι συνδεδομενος, η σελιδα κληθηκε μεσω POST και αν υπαρχει το reservation_id //
//Αν καποιο λειπει παμε ξανα στο my_trips.php//
if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['reservation_id'])) {
    header("Location: my_trips.php");
    exit();
}
// Εφοσον υπαρχουν παιρνουμε τα δεδομενα απο την βαση//
$reservation_id = (int)$_POST['reservation_id'];
$user_id = $_SESSION['user_id'];

// Εκτελω SQL για να επιβεβαιωθει οτι η κρατηση υπαρχει και ανηκει στο συγκεκριμενο χρηστη//
$stmt = $pdo->prepare("SELECT flight_date FROM reservations WHERE reservation_id = ? AND user_id = ?");
$stmt->execute([$reservation_id, $user_id]);
$reservation = $stmt->fetch();

if (!$reservation) { // Αν δεν υπαρχει ανακατευθυνει με μηνυμα σφαλματος //
    header("Location: my_trips.php?error=not_found");
    exit();
}

// Εδω απλα γινεται ο υπολογισμος ημερων διαφορας //
$flightDate = new DateTime($reservation['flight_date']);
$today = new DateTime();
$interval = $today->diff($flightDate);
$daysDiff = (int)$interval->format('%r%a'); // το %r%a κραταει το θετικο //

//Ελεγχω αν επιτρεπεται η ακυρωση //
if ($daysDiff < 30) { 
    header("Location: my_trips.php?error=not_allowed");
    exit();
}

// Εδω διαγραφεται η κρατηση απο την βαση μας//
$stmt = $pdo->prepare("DELETE FROM reservations WHERE reservation_id = ? AND user_id = ?");
$stmt->execute([$reservation_id, $user_id]);

// Ανακατευθυνση στο mytrip.php //
header("Location: my_trips.php?cancelled=1");
exit();
