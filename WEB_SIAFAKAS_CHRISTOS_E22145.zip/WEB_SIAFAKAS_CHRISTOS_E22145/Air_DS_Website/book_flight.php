<?php
session_start();
include 'connection.php';

// Αν σταλθηκε η φορμα με POSΤ, αποθηκευονται ολα τα first & last names αναλογα ποσοι επιβατες ειναι //
// Τα δεδομενα μπαινιυν σε session για να μεταφερθουν στο επομενο βημα//
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['passenger_names'] = [
        'first_names' => $_POST['first_name'],
        'last_names' => $_POST['last_name']
    ];
    header("Location: choose_seats.php");
    exit();
}

// Ελεγχος login και κρατησης μονο για GET //
if (!isset($_SESSION['user_id']) || !isset($_SESSION['reservation'])) {
    header("Location: Home.php");
    exit();
}

// απλα θα παρουμε ολα τα στοιχεια που εβαλε στο Home.php σε μεταβλητες //
$reservation = $_SESSION['reservation'];
$departure = htmlspecialchars($reservation['departure']);
$arrival = htmlspecialchars($reservation['arrival']);
$date = htmlspecialchars($reservation['date']);
$passengers = intval($reservation['passengers']);


include 'connection.php';

// Εδω απλα μεσω της βασης αφου την συνδεσαμε παραπανω παιρνουμε το ονομα και το επωνυμο //
$stmt = $pdo->prepare("SELECT first_name, last_name FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    echo "Ο χρηστης δεν βρεθηκε.";
    exit();
}

$firstName = $user['first_name'];
$lastName = $user['last_name'];
?>

<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <title>Επιλογη Θεσεων</title>
 
</head>

<?php include 'navbar.php'; ?>

<body>

<h2>Επιλογη Θεσεων (Επιβάτες: <?= $passengers ?>)</h2>

<form action="save_passenger_data.php" method="POST"> <!-- Εδω το action λεει οτι τα δεδομενα της φορμας θα αποσταλουν στο αρχειο save_passenger_data.php μεσω της Post -->
  <!--Τα στοιχεια του εγγεγραμενου χρηστη προ-συμπληρωμενα -->
  <fieldset> <!-- Αυτο εχει να κανει καπως με την ομαδοποιηση των περιεχομενων -->
    <legend>Επιβατης 1 (Εγγεγραμμενος χρηστης)</legend> <!-- Σαν τιτλος του fieldest -->
    <label>Ονομα:</label>
    <input type="text" name="first_name[]" value="<?= $firstName ?>" readonly>
    <label>Επωνυμο:</label>
    <input type="text" name="last_name[]" value="<?= $lastName ?>" readonly>
  </fieldset>

  <!-- Για οσους χρηστες βαλει ο εγγεγραμμενος χρηστης τοσο κουτακια/πεδια θα εμφανισουμε  -->
  <?php
  for ($i = 1; $i < $passengers; $i++) {
      echo "<fieldset>
              <legend>Επιβάτης " . ($i + 1) . "</legend>
              <label>Ονομα:</label>
              <input type='text' name='first_name[]' pattern='[A-Za-zΑ-Ωα-ω]{3,20}' required>
              <label>Επωνυμο:</label>
              <input type='text' name='last_name[]' pattern='[A-Za-zΑ-Ωα-ω]{3,20}' required>
            </fieldset>";
  }
  ?>

  <button type="submit">Επιβεβαιωση Στοιχειων</button>
</form>

</body>

<footer style="padding: 20px;">
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">

    <div>
      <h3>Τα στοιχεια Επικοινωνιας ειναι:</h3>
      <p>Όνομα: Air DS</p>
      <p>Τηλεφωνο: <a href="tel:+302109304070">2109304070</a></p>
      <p>Email: <a href="mailto:info@AIRINTERSALONIKA.gr">info@AIRINTERSALONIKA.gr</a></p>
    </div>

    <div>
      <h3>Η Τοποθεσια μας ειναι:</h3>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3146.522177474548!2d23.945142575701148!3d37.94159177194379!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1901ad9e75c61%3A0x38b215df0aeeb3aa!2zzpTOuc61zrjOvc6uz4IgzpHOtc-Bzr_Ou865zrzOrc69zrHPgiDOkc64zrfOvc-Ozr0gzpXOu861z4XOuM6tz4HOuc6_z4IgzpLOtc69zrnOts6tzrvOv8-C!5e0!3m2!1sel!2sgr!4v1747690775457!5m2!1sel!2sgr"
        width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
      </iframe>
    </div>

  </div>
</footer>
</html>

