<?php
session_start();
include 'connection.php';

//Αν υπαρχει ο χρηστης//
if (!isset($_SESSION['user_id'])) {
    header("Location: login_register.php?error=not_logged_in&form=login");
    exit();
}

$departure = $_POST['departure_airport'] ?? '';
$arrival = $_POST['arrival_airport'] ?? '';
$date = $_POST['flight_date'] ?? '';
$passengers = intval($_POST['passengers_count'] ?? 0);

// Έλεγχει αν ειναι empty //
if ($departure === $arrival || empty($departure) || empty($arrival) || empty($date) || $passengers < 1) {
    header("Location: Home.php?error=invalid_data");
    exit();
}

// Αποθηκευση στοιχειων κρατησης στο session//
$_SESSION['reservation'] = [
    'departure' => $departure,
    'arrival' => $arrival,
    'date' => $date,
    'passengers' => $passengers
];

// Μεταβαση στο book_flight.php για να ολοκληρωθει η κρατηση //
header("Location: book_flight.php");
exit();

?>
