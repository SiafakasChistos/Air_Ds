<?php
session_start(); // εδω απλα συνεχιζει το session με σκοπο να αποθηκευτει οτι ο χρηστης εχει κανει login και να το δει το index.php//
include 'connection.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        header("Location: login_register.php?error=empty_login&form=login"); // Αυτο το alert δεν προκειται να ενωργοποιηθει γιατι στο login_register.js εχουμε βαλει required αρα ο browser θα βγαλει το δικο του μηνυμα//
        exit();
    }

    // Παρακατω απλα ψαχουμε το username & password στην βαση μας //
    $stmt = $pdo->prepare("SELECT id, password FROM users WHERE username = :username");
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch();

    if (!$user || $password !== $user['password']) {
        header("Location: login_register.php?error=invalid_login&form=login");
        exit();
    }
    
    $_SESSION['user_id'] = $user['id']; // Αποθηκευση με βαση το id //
    header("Location: Home.php"); // Αν ολα ειναι ενταξει τον στελνει στην ουσια στο interface1//
    exit(); 
}
