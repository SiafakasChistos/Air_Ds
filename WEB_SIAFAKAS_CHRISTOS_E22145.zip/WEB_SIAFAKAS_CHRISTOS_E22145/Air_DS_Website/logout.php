<?php
session_start(); // Ξεκιναει το τρεχον session //
session_unset();  // Σαν να "καθαριζει" ολα τα δεδομενα που ειναι αποθηκευμενα στο SESSION //
session_destroy(); // Καταστρεφει εντελως το session //
header("Location: login_register.php"); // Παει το χρηστη στην σελιδα login/register //
exit(); // Σημαντικο διακοπτει αμεσως την εκτελεση του script//
