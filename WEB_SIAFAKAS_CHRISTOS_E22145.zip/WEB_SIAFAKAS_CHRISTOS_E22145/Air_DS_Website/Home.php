<?php
include 'connection.php'; //Κανω στην ουσια include την βαση μου//

$airports = $pdo->query("SELECT * FROM airports")->fetchAll(); //Απο την βαση μου παιρνω ολα τα αεροδρομια και τα βαζω στο πινακα airports//

session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: login_register.php?error=not_logged_in&form=login");
  exit();
} // Ελεγχω αν ο χρηστης ειναι συνδεδεμενος//
$loggedIn = true; // για να φτασει εδω σημαινει οτι εχει ελεγχει οτι ο χρηστης αν εχει κανει login ή οχι //
?>

<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <title>Air DS</title>
</head>
<?php include 'navbar.php'; ?>

<body>
  <h1>Σας Καλωσοριζουμε στην Αεροπορικη μας εταιρια</h1>
  <h2>Κανε την Κρατηση σου</h2>
  <form action="process_reservation.php" method="POST" id="bookingForm" onsubmit="return checkAirports(this);">

    <label>Αεροδρομιο Αναχωρησης:</label>
    <select name="departure_airport" id="departure" required> 
      <option value="">-- Επιλέξτε --</option> 
      <?php foreach ($airports as $airport): ?> <!-- Εδω απλα διατρεχουμε ολα τα αεροδρομια που πηραμε παραπανω απο την βαση και βαλαμε στο πινακα airports και τα εμφανιζουμε σε μια dropdown λιστα -->
        <option value="<?= $airport['code'] ?>">
          <?= $airport['name'] ?> (<?= $airport['code'] ?>) 
        </option>
      <?php endforeach; ?> 
    </select>

    <label>Αεροδρομιο Αφιξης:</label>
    <select name="arrival_airport" id="arrival" required>
      <option value="">-- Επιλέξτε --</option>
      <?php foreach ($airports as $airport): ?>  <!--Το ιδιο με πριν-->
        <option value="<?= $airport['code'] ?>">
          <?= $airport['name'] ?> (<?= $airport['code'] ?>)
        </option>
      <?php endforeach; ?>
    </select>

    <label>Ημερομηνία Πτήσης:</label>
    <?php $today = date('Y-m-d'); ?>
    <input type="date" name="flight_date" min="<?= $today ?>" required>

    <label>Αριθμός Επιβατών:</label>
    <input type="number" name="passengers_count" min="1" value="1" required>

    <button type="submit" <?= $loggedIn ? '' : 'disabled' ?>>Κρατηση</button> <!-- Εδω μπορει να πατησει το κουμπι αν και μονο αν εχει κανει login-->
  </form>

  <?php if (!$loggedIn): ?> <!--Ειναι απλα ενα μηνυμα ενημερωτικο-->
    <p><strong>Πρεπει να κανετε login για να ολοκληρωσετε κρατηση.</strong></p>
  <?php endif; ?>
  
 
 <!--Σημαντικο: Ο ελεγχος που γινεται για το αν το αερροδρομιο αναχωρησης ειναι το ιδιο με το αεροδρομιο αφιξης
 ενεργοποιειται μονο οταν κανει login.Συγκεκριμενα αν δε εχει κανει login το κουμπι κρατηση ειναι disable
  αρα το checkAirports δεν εκτελειται καθολου-->
</body>

<footer style="padding: 20px;">
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">

    <div>
      <h3>Τα στοιχεια Επικοινωνιας ειναι:</h3>
      <p>Όνομα: Air DS</p>
      <p>Τηλεφωνο: <a href="tel:+302109304070">2109304070</a></p>
      <p>Email: <a href="mailto:info@AIRINTERSALONIKA.gr">info@AIRINTERSALONIKA.gr</a></p>
    </div>

    <div>
      <h3>Η Τοποθεσια μας ειναι:</h3>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3146.522177474548!2d23.945142575701148!3d37.94159177194379!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1901ad9e75c61%3A0x38b215df0aeeb3aa!2zzpTOuc61zrjOvc6uz4IgzpHOtc-Bzr_Ou865zrzOrc69zrHPgiDOkc64zrfOvc-Ozr0gzpXOu861z4XOuM6tz4HOuc6_z4IgzpLOtc69zrnOts6tzrvOv8-C!5e0!3m2!1sel!2sgr!4v1747690775457!5m2!1sel!2sgr"
        width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
      </iframe>
    </div>

  </div>
</footer>
<script src="Home.js"></script> 
</html> 