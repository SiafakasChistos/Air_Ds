<?php
session_start();

// Κλασικος ελεγχος//
if (!isset($_SESSION['user_id']) || !isset($_SESSION['reservation'])) {
    header("Location: Home.php");
    exit();
}

// Αναθεση μεταβλητων//
$reservation = $_SESSION['reservation'];
$passengers = intval($reservation['passengers']);
$departure = $reservation['departure'];
$arrival = $reservation['arrival'];

include 'connection.php';

// Παρνει τις κρατημενες θεσεις για το συγκεκριμενο δρομολογιο και ημερομηνια //
$bookedSeats = [];

// Ζητα απο το reservation οσες εγγραφες εχουν συγκεκριμενη ημερομηνια πτησης , συγκεκριμενο αεροδρομιο και συγκεκριμενο αεροδρομιο αφιξης //
$stmt = $pdo->prepare("
    SELECT reserved_seats 
    FROM reservations 
    WHERE flight_date = ? AND departure_airport = ? AND arrival_airport = ?
");
$stmt->execute([$reservation['date'], $reservation['departure'], $reservation['arrival']]);



while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    if (!empty($row['reserved_seats'])) {
        $seats = explode(',', $row['reserved_seats']);
        $bookedSeats = array_merge($bookedSeats, $seats);
    }
}


?>

<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <title>Επιλογη Θεσεων</title>
  <link rel="stylesheet" href="book_flights.css">
</head>
<?php include 'navbar.php'; ?>
<body>

<h2>Επιλογη Θεσεων (Επιβατες: <?= $passengers ?>)</h2>
<!-- Για την αποστολη στο confirm_booking.php -->
<form action="confirm_booking.php" method="POST" onsubmit="return validateSelection();">
  <div class="plane">
    <div class="select">
      <h1>Παρακαλω επιλεξτε <?= $passengers ?> θεσεις</h1>
    </div>
    <div class="exit"></div>  
    <ol>
      <?php
      for ($i = 1; $i <= 31; $i++) {  // Για καυε αριθμο σειρας i δημιουργειται ενα ol καθισματων //
        echo "<li><ol class='seats'>";

        foreach (['A', 'B', 'C'] as $col) { // Δημιουργια θεσεων αριστερα του διαδρομου, δημιουεγει δηλαδη 1Α ,1Β κλπ...//
            $seat = $i . $col;
            $cost = in_array($i, [1, 11, 12]) ? 20 : (($i >= 2 && $i <= 10) ? 10 : 0); //Υπολογιζει το κοστους της θεσης σνσλογα με τη σειρα //
            $seatClass = in_array($seat, $bookedSeats) ? 'seat taken' : 'seat active'; // Ελεγχος αν η θεση ειναι κρατημενη//
            //Δημιοργει checkbox για την επιλογη της θεσης και το checkbox απενεργοποιεται αν η θεση ειναι ηδη κρατημενη //
            echo "<li class='$seatClass'><input type='checkbox' id='$seat' name='selected_seats[]' value='$seat' " . ($seatClass == 'seat taken' ? 'disabled' : '') . ">";
            echo "<label for='$seat'>$seat (€$cost)</label></li>";
        }

        echo "<li class='aisle'><span>$i</span></li>"; //Εδω τοποθετει τον αριθμο της σειρας μεσα στο διαδρομο //

        foreach (['D', 'E', 'F'] as $col) { //Αντιστοιχα με πριν δημιουργια θεσεων δεξια του διαδρομου //
            $seat = $i . $col;
            $cost = in_array($i, [1, 11, 12]) ? 20 : (($i >= 2 && $i <= 10) ? 10 : 0);
            $seatClass = in_array($seat, $bookedSeats) ? 'seat taken' : 'seat active';
            echo "<li class='$seatClass'><input type='checkbox' id='$seat' name='selected_seats[]' value='$seat' " . ($seatClass == 'seat taken' ? 'disabled' : '') . ">";
            echo "<label for='$seat'>$seat (€$cost)</label></li>";
        }

        echo "</ol></li>";
      }
      ?>
    </ol>
  </div>

  
  <input type="hidden" id="selectedSeatsDisplay">  <!-- Κρατα τις θεσεις για εμφανιση -->
 
  <div class="seat-info" id="seatInfo"></div> <!-- Εμφανιζει κοστος και επιλογες -->

  <button type="submit">Ολοκλήρωση Κράτησης</button>
</form>

<script> // Ενημερωνει τη javascript με το ποσες θεσεις επιτρεπονται //
  const maxSeats = <?= $passengers ?>;
</script>
<script src="choose_seats.js"></script>

</body>
</html>
