<?php // Σκοπος υπαρξης ειναι κυριως να καταχωρει τα δεδομενα στην βαση δεδομενων , αποθηκευοντας την κρατηση //
session_start();
include 'connection.php';

// Ξανα ελεγχος αν ο χρηστης ειναι συνδεδεμενος//
if (!isset($_SESSION['user_id']) || !isset($_SESSION['reservation']) || !isset($_SESSION['passenger_names'])) {
    header("Location: Home.php");
    exit();
}

// Παιρνει τις θεσεις από το POST που εχουν επιβεβαιωθει αν δεν εχει επιλεξει θεσεις εμφανιζει αναλογο μηνυμα//
$seats = $_POST['confirmed_seats'] ?? '';
if (empty($seats)) {
    die("Σφάλμα: Δεν βρέθηκαν επιλεγμένες θέσεις.");
}

$selectedSeatsArray = explode(',', $seats);

// Παιρνει τα υπολοιπα από το session //
$userId = $_SESSION['user_id'];
$res = $_SESSION['reservation'];
$passengerCount = count($selectedSeatsArray);
$firstNames = $_SESSION['passenger_names']['first_names'];
$lastNames = $_SESSION['passenger_names']['last_names'];

// Αποθηκευση της κρατησης στη βαση //
$stmt = $pdo->prepare("
    INSERT INTO reservations (user_id, departure_airport, arrival_airport, flight_date, passengers_count, reserved_seats)
    VALUES (?, ?, ?, ?, ?, ?)
");
$stmt->execute([
    $userId,
    $res['departure'],
    $res['arrival'],
    $res['date'],
    $passengerCount,
    implode(',', $selectedSeatsArray)
]);

// Προαιρετικα αποθηκευση επιβατων σε ξεχωριστο πινακα passengers //

// Καθαρισμος session εφοσον δε τα χρειαζομαστε πλεον //
unset($_SESSION['reservation']);
unset($_SESSION['passenger_names']);

// Εμφάνιση μηνυματος επιτυχιας //
?>

<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <title>Επιτυχης Κρατηση</title>
</head>
<?php include 'navbar.php'; ?>

<body>
  <h1>✅ Η κρατηση σας ολοκληρωθηκε με επιτυχια!</h1>
  <p>Σας ευχαριστουμε που επιλεξατε την Air DS.</p>
  <p><a href="my_trips.php">Δειτε τις κρατησεις σας</a></p>
  <p><a href="Home.php">Επιστροφη στην αρχικη</a></p>
</body>
<footer style="padding: 20px;">
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">

    <div>
      <h3>Τα στοιχεια Επικοινωνιας ειναι:</h3>
      <p>Όνομα: Air DS</p>
      <p>Τηλεφωνο: <a href="tel:+302109304070">2109304070</a></p>
      <p>Email: <a href="mailto:info@AIRINTERSALONIKA.gr">info@AIRINTERSALONIKA.gr</a></p>
    </div>

    <div>
      <h3>Η Τοποθεσια μας ειναι:</h3>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3146.522177474548!2d23.945142575701148!3d37.94159177194379!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1901ad9e75c61%3A0x38b215df0aeeb3aa!2zzpTOuc61zrjOvc6uz4IgzpHOtc-Bzr_Ou865zrzOrc69zrHPgiDOkc64zrfOvc-Ozr0gzpXOu861z4XOuM6tz4HOuc6_z4IgzpLOtc69zrnOts6tzrvOv8-C!5e0!3m2!1sel!2sgr!4v1747690775457!5m2!1sel!2sgr"
        width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
      </iframe>
    </div>

  </div>
</footer>
</html>
