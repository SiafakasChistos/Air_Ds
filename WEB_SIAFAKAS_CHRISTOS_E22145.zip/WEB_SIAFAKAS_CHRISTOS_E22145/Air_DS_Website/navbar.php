<?php
if (session_status() === PHP_SESSION_NONE) { // Ελεγχει αν εχει ηδη ξεκινησει το session, αν οχι κανει session_start για να εχει εννοειται προσβαση σε session μεταβλητες//
    session_start();
}
$loggedIn = isset($_SESSION['user_id']); //Αν εχει κανει login τοτε η μεταβλητη loggedIn θα παρει την τιμη true //
?>


<style>
 
  nav {
    background-color: #004080;
    color: white;
    padding: 10px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
  }

  nav .logo {
    font-weight: bold;
    font-size: 1.5em;
  }

  nav ul {
    list-style: none;
    display: flex;
    margin: 0;
    padding: 0;
  }

  nav ul li {
    margin-left: 20px;
  }

  nav ul li a {
    color: white;
    text-decoration: none;
    font-weight: 600;
  }

  
  .menu-toggle {
    display: none;
    flex-direction: column;
    cursor: pointer;
  }

  .menu-toggle div {
    width: 25px;
    height: 3px;
    background: white;
    margin: 4px 0;
  }

  @media (max-width: 768px) {
    nav ul {
      display: none;
      width: 100%;
      flex-direction: column;
    }
    nav ul.showing {
      display: flex;
    }
    .menu-toggle {
      display: flex;
    }
  }
</style>
<!-- Δημιουργια navigation menu -->
<nav>
  <div class="logo">Air DS</div>
  <div class="menu-toggle" id="menu-toggle">
    <div></div>
    <div></div>
    <div></div>
  </div>
  <ul id="nav-menu">
    <li><a href="Home.php">Home</a></li>
    <li><a href="my_trips.php">My Trips</a></li>
    <li> <!-- Το σημαντικο εδω ειναι οτι αν ο χρηστης ειναι συνδεδεμος τοτε εμφανιζεται η επιλογη logout αλλιως η επιλογη login -->
      <?php if ($loggedIn): ?>
        <a href="logout.php">Logout</a>
      <?php else: ?>
        <a href="login_register.php?form=login">Login</a>
      <?php endif; ?>
    </li>
  </ul>
</nav>

<script>
  const menuToggle = document.getElementById('menu-toggle');
  const navMenu = document.getElementById('nav-menu');

  menuToggle.addEventListener('click', () => {
    navMenu.classList.toggle('showing');
  });
</script>
