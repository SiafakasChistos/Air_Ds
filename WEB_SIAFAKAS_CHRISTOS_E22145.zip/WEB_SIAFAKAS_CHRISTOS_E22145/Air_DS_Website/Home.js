function checkAirports(form) {
    var departure = document.getElementById('departure').value;
    var arrival = document.getElementById('arrival').value;
  
    if (departure === arrival) {
      alert("το αεροδρομιο αφιξης δεν μπορεί να είναι ίδιο με το αναχωρησης.");
      return false; 
    }
  
    return true; 
}