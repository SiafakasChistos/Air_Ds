<?php // Αρχικα ο ρολος υπαρξης του save_passenger_data.php ειναι η αποθηκευση των στοιχειων των επιβατων 
//που εισαγει ο χρηστης κατα την διαδικασια κρατησης και να τα μεταφερει στην επομενη σελιδα choose_seats.php//
//Ειχα το προβλημα οτι οταν ο χρηστης συμπληρωνε τα ονοματα στο book_flight.php η φορμα εκανε action= choose_seats.php και η choose προσπαθουσε να διαβασει τα  ονοματα με POST αλλα αυτα δεν αποστελλονταν //

session_start();

// Έλεγχος εαν υποβληθηκε η φορμα σωστα//
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Αποθήκευση των ονοματων και επωνυμων των επιβατων//
    $_SESSION['passenger_names'] = [
        'first_names' => $_POST['first_name'],
        'last_names' => $_POST['last_name']
    ];

    // Ανακατευθυνση στο choose_seats.php //
    header("Location: choose_seats.php");
    exit();
} else {
    // Αν καποιος προσπαθησει να μπει απευθειας χωρίς POST //
    header("Location: book_flight.php");
    exit();
}
