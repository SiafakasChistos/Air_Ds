<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Κλασικα γινεται για λογους ασφαλειας γινεται ελεγχος προσβασης χρηστη //
session_start();
include 'connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login_register.php");
    exit();
}

$userId = $_SESSION['user_id'];

// Στην ουσια φερνει ολες τις κρατησεις του χρηστη μαζι με τα στοιχεια των αεροδρομιων , την ημερομηνια , τις θεσεις και τους επιβατες //
$stmt = $pdo->prepare("
    SELECT r.*, 
           a1.name AS departure_name, a1.tax AS departure_tax, a1.latitude AS dep_lat, a1.longitude AS dep_lon,
           a2.name AS arrival_name, a2.tax AS arrival_tax, a2.latitude AS arr_lat, a2.longitude AS arr_lon
    FROM reservations r
    JOIN airports a1 ON r.departure_airport = a1.code
    JOIN airports a2 ON r.arrival_airport = a2.code
    WHERE r.user_id = ?
    ORDER BY r.flight_date DESC
");
$stmt->execute([$userId]);
$reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Υπολογισμος του κοστους θεσης //
function seatCost($row) {
    if (in_array($row, [1,11,12])) return 20;
    if ($row >= 2 && $row <= 10) return 10;
    return 0;
}
// Η συναρτηση haversine ειναι εμνευσμενο απο τις συμβουλες στην εκφνωνηση της εργασιας υπολογιζει την αποσταση μεταξυ 2 σημειων (πλατος και μηκος) //
function haversine($lat1, $lon1, $lat2, $lon2) {
    $R = 6371;
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $lat1 = deg2rad($lat1);
    $lat2 = deg2rad($lat2);

    $a = sin($dLat/2) * sin($dLat/2) + cos($lat1)*cos($lat2)*sin($dLon/2)*sin($dLon/2);
    $c = 2 * asin(sqrt($a));
    return $R * $c;
}

$today = new DateTime();

// Μηνυματα για το αν ακυρωθηκε ή οχι η κρατηση
$cancelMsg = '';
if (isset($_GET['cancelled']) && $_GET['cancelled'] == 1) {
    $cancelMsg = "Η κρατηση ακυρωθηκε επιτυχως.";
}
if (isset($_GET['error'])) {
    if ($_GET['error'] == 'not_allowed') {
        $cancelMsg = "Η ακύρωση επιτρέπεται μόνο 30 ή περισσότερες μέρες πριν την πτήση.";
    } elseif ($_GET['error'] == 'not_found') {
        $cancelMsg = "Δεν βρέθηκε η κράτηση ή δεν έχετε δικαίωμα ακύρωσης.";
    }
}
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <title>Τα Ταξιδια Μου</title>
    <style>
        table {border-collapse: collapse; width: 100%; margin-top: 20px;}
        th, td {border: 1px solid #ccc; padding: 8px; text-align: center;}
        th {background-color: #eee;}
        button {padding: 5px 10px; cursor: pointer;}
        .message {background-color: #d4edda; color: #155724; padding: 10px; margin-bottom: 15px; border-radius: 5px;}
        .error {background-color: #f8d7da; color: #721c24; padding: 10px; margin-bottom: 15px; border-radius: 5px;}
    </style>
</head>
<?php include 'navbar.php'; ?> <!-- καλει στην ουσια το navbar.php -->

<body>

<h1>Τα Ταξιδια Μου</h1>
 
<!-- Αν υπαρχουν μηνυματα επιτυχιας ή λαθους -->
<?php if ($cancelMsg): ?> <!-- Αν το μηνυμα ξεκιναει με Δεν παιρνει ως ορισμα το error αλλιως παιρνει το message -->
    <div class="<?= (strpos($cancelMsg, 'Δεν') === 0 || strpos($cancelMsg, 'Η ακυρωση') === 0) ? 'error' : 'message' ?>">
        <?= htmlspecialchars($cancelMsg) ?> <!-- το htmlspecialchars τυπωνει με ασφαλεια το μηνυμα -->
    </div>
<?php endif; ?>

<!-- Αν δε υπαρχουν κρατησεις εμφανιζεται αυτο -->
<?php if (empty($reservations)): ?>
    <p>Δεν εχετε πραγματοποιησει καμια κρατηση.</p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Ημερομηνια Πτησης</th>
                <th>Αναχωρηση</th>
                <th>Αφιξη</th>
                <th>Θεσεις</th>
                <th>Επιβατες</th>
                <th>Φοροι (€)</th>
                <th>Κοστος Θεσεων (€)</th>
                <th>Τελικο Κοστος (€)</th>
                <th>Ενεργειες</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reservations as $r): // Αρχιζει επαναληψη για καθε κρατηση που εχει φερει απο την βαση δεδομενων//
            //Υπολογιζει ποσες μερες απομενουν ή περασαν μεχρι την πτηση με - (περασαν) + (απομενουν) και το κανει για να δει αν επιτρεπεται ή ακυρωση//
                $flightDate = new DateTime($r['flight_date']);
                $interval = $today->diff($flightDate);
                $daysDiff = (int)$interval->format('%r%a'); 
                
                // Υπολογιζει το κοστος //
                // Εδω γινεται ο υπολογισμος με βασης τις γεωγραφικες αποστασεις//
                $distance = haversine($r['dep_lat'], $r['dep_lon'], $r['arr_lat'], $r['arr_lon']);
                $flightCost = $distance / 10;
                $taxes = $r['departure_tax'] + $r['arrival_tax']; // Οι φοροι που εχει το αεροδρομιο //
               // Υπολογιζει το κοστος της θεσεις διασποντας το πεδιο reserved_seats σε πινακα και παιρνει τον αριθμο σειρας //
                $seats = explode(',', $r['reserved_seats']);
                $seatTotalCost = 0;
                foreach ($seats as $seat) {
                    $row = intval(preg_replace('/\D/', '', $seat));
                    $seatTotalCost += seatCost($row);
                }
                //εδω γινεται ο συνολικο υπολογισμος//
                $ticketCost = $taxes + $flightCost + $seatTotalCost; // Υπολογιζει το κοστος ανα εισιτηριο //
                $totalCost = $ticketCost * $r['passengers_count']; // Εδω αναλογα με το ποσοι επιβατες ειναι κανει και τον αντιστοιχο υπολογισμο //
            ?>
            <tr> <!-- εμφανιζει ημερομηνια πτησης , ονομα αεροδρομιου αναχωρησης και αφιξης , θεσεις , αριθμο επιβατων , αναλυτικα το καθε κοστος -->
                <td><?= htmlspecialchars($r['flight_date']) ?></td>
                <td><?= htmlspecialchars($r['departure_name']) ?></td>
                <td><?= htmlspecialchars($r['arrival_name']) ?></td>
                <td><?= htmlspecialchars($r['reserved_seats']) ?></td>
                <td><?= htmlspecialchars($r['passengers_count']) ?></td>
                <td><?= number_format($taxes, 2) ?></td>
                <td><?= number_format($seatTotalCost, 2) ?></td>
                <td><?= number_format($totalCost, 2) ?></td>
                <td> <!-- Αν η πτηση ειναι τουλσχιστον 30 μερες μακρια μπορει να πατησει το κουμπι ακυρωσεις αλλιως τι κουμπι ειναι απενεργοποιημενο -->
                    <?php if ($daysDiff >= 30): ?> 
                        <form method="POST" action="cancel_booking.php" onsubmit="return confirm('Είστε σίγουροι ότι θέλετε να ακυρώσετε αυτή την κράτηση;');">
                            <input type="hidden" name="reservation_id" value="<?= (int)$r['reservation_id'] ?>">
                            <button type="submit">Ακύρωση</button>
                        </form>
                    <?php else: ?>
                        <button disabled title="Ακύρωση επιτρέπεται μόνο 30+ μέρες πριν">Ακύρωση</button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

</body>
<footer style="padding: 20px;">
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">

    <div>
      <h3>Τα στοιχεια Επικοινωνιας ειναι:</h3>
      <p>Όνομα: Air DS</p>
      <p>Τηλεφωνο: <a href="tel:+302109304070">2109304070</a></p>
      <p>Email: <a href="mailto:info@AIRINTERSALONIKA.gr">info@AIRINTERSALONIKA.gr</a></p>
    </div>

    <div>
      <h3>Η Τοποθεσια μας ειναι:</h3>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3146.522177474548!2d23.945142575701148!3d37.94159177194379!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1901ad9e75c61%3A0x38b215df0aeeb3aa!2zzpTOuc61zrjOvc6uz4IgzpHOtc-Bzr_Ou865zrzOrc69zrHPgiDOkc64zrfOvc-Ozr0gzpXOu861z4XOuM6tz4HOuc6_z4IgzpLOtc69zrnOts6tzrvOv8-C!5e0!3m2!1sel!2sgr!4v1747690775457!5m2!1sel!2sgr"
        width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
      </iframe>
    </div>

  </div>
</footer>
</html>

