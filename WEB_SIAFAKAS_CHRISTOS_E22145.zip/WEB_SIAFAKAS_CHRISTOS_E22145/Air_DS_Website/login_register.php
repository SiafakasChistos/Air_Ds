<?php
$form = $_GET['form'] ?? 'login'; //Εδω στην ουσια διαβαζει την form απο το URL //
?>

<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <title>Σύνδεση / Εγγραφή</title>
  <style>
     body { font-family: sans-serif; padding: 20px; }
    label, input { display: block; margin: 5px 0; }
    .form-container { display: none; margin-bottom: 20px; }
  </style>
</head>
<?php include 'navbar.php'; ?>


<body>

  <h1>Καλώς ήρθατε</h1>

  <button onclick="showForm('login')">Σύνδεση</button> <!--καλει την showform(login)-->
  <button onclick="showForm('register')">Εγγραφή</button> <!-- καλει την showform(register)-->

  <!--Φορμα Συνδεσης-->
  <div id="login" class="form-container">
    <h2>Σύνδεση</h2>
    <form action="login.php" method="POST">
      <label for="login_username">Όνομα Χρήστη:</label>
      <input type="text" name="username" id="login_username" required>

      <label for="login_password">Κωδικός:</label>
      <input type="password" name="password" id="login_password" required>

      <button type="submit">Σύνδεση</button>
    </form>
  </div>

  <!--Φορμα εγγραφης -->
  <div id="register" class="form-container">
    <h2>Εγγραφή</h2>
    <form action="register.php" method="POST">
      <label for="first_name">Όνομα:</label>
      <input type="text" name="first_name" id="first_name" required>

      <label for="last_name">Επώνυμο:</label>
      <input type="text" name="last_name" id="last_name" required>

      <label for="username">Όνομα Χρήστη:</label>
      <input type="text" name="username" id="username" required>

      <label for="password">Κωδικός:</label>
      <input type="password" name="password" id="password" required>

      <label for="email">Email:</label>
      <input type="email" name="email" id="email" required>

      <button type="submit">Εγγραφή</button>
    </form>
  </div>

  
  <footer style="padding: 20px;">
  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">

    <div>
      <h3>Τα στοιχεια Επικοινωνιας ειναι:</h3>
      <p>Όνομα: Air DS</p>
      <p>Τηλεφωνο: <a href="tel:+302109304070">2109304070</a></p>
      <p>Email: <a href="mailto:info@AIRINTERSALONIKA.gr">info@AIRINTERSALONIKA.gr</a></p>
    </div>

    <div>
      <h3>Η Τοποθεσια μας ειναι:</h3>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3146.522177474548!2d23.945142575701148!3d37.94159177194379!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1901ad9e75c61%3A0x38b215df0aeeb3aa!2zzpTOuc61zrjOvc6uz4IgzpHOtc-Bzr_Ou865zrzOrc69zrHPgiDOkc64zrfOvc-Ozr0gzpXOu861z4XOuM6tz4HOuc6_z4IgzpLOtc69zrnOts6tzrvOv8-C!5e0!3m2!1sel!2sgr!4v1747690775457!5m2!1sel!2sgr"
        width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
      </iframe>
    </div>

  </div>
</footer>

  <script src="login_register.js"></script>

  <noscript>
  <div style="padding: 10px; background-color: #ffe0e0; color: red; font-weight: bold; margin-bottom: 20px; border: 1px solid red;">
     Η JavaScript είναι απενεργοποιημενη. Καποιες λειτουργιες δεν θα λειτουργουν σωστα.
  </div>
</noscript>


</body>
</html>
